//
//  ViewController.swift
//  NavigationController-1
//
//  Created by Ma Guadalupe Brizuela on 30/04/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

