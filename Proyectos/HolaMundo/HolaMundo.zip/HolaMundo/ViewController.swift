//
//  ViewController.swift
//  HolaMundo
//
//  Created by Ma Guadalupe Brizuela on 29/04/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let cadena:String = "Desarrollo en Ios"
        
        print("Este es un mensaje antes del breakpoint")
        
        print("Este es un mensaje posterior al breakpoint")
        print(cadena)
        // Do any additional setup after loading the view.
    }


}

